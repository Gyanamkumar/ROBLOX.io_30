# train.py
# REWRITTEN TO USE DEEPLABV3+ ARCHITECTURE

import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from PIL import Image
import glob
from sklearn.model_selection import train_test_split
import logging
import traceback

# --- 1. DEEPLABV3+ MODEL DEFINITION ---
# Based on the official Keras.io example

def convolution_block(
    block_input,
    num_filters=256,
    kernel_size=3,
    dilation_rate=1,
    use_bias=False,
):
    x = layers.Conv2D(
        num_filters,
        kernel_size=kernel_size,
        dilation_rate=dilation_rate,
        padding="same",
        use_bias=use_bias,
        kernel_initializer=keras.initializers.HeNormal(),
    )(block_input)
    x = layers.BatchNormalization()(x)
    return layers.ReLU()(x)

def DilatedSpatialPyramidPooling(dspp_input):
    dims = dspp_input.shape
    x = layers.AveragePooling2D(pool_size=(dims[1], dims[2]))(dspp_input)
    x = convolution_block(x, kernel_size=1, use_bias=True)
    out_pool = layers.UpSampling2D(
        size=(dims[1] // x.shape[1], dims[2] // x.shape[2]),
        interpolation="bilinear",
    )(x)

    out_1 = convolution_block(dspp_input, kernel_size=1, dilation_rate=1)
    out_6 = convolution_block(dspp_input, kernel_size=3, dilation_rate=6)
    out_12 = convolution_block(dspp_input, kernel_size=3, dilation_rate=12)
    out_18 = convolution_block(dspp_input, kernel_size=3, dilation_rate=18)

    x = layers.Concatenate(axis=-1)([out_pool, out_1, out_6, out_12, out_18])
    output = convolution_block(x, kernel_size=1)
    return output

def build_deeplabv3plus(input_shape, num_classes):
    """Builds a DeepLabV3+ model with a ResNet50 backbone, adapted for 4-channel input."""

    # --- 1. Build the ResNet50 Feature Extractor ---
    # Create a standard ResNet50 model. This will load weights correctly.
    resnet50_base = keras.applications.ResNet50(
        weights="imagenet", include_top=False, input_shape=(input_shape[0], input_shape[1], 3)
    )
    # Create a new, non-trainable model that extracts the two feature maps we need.
    feature_extractor = keras.Model(
        inputs=resnet50_base.input,
        outputs=[
            resnet50_base.get_layer("conv4_block6_out").output, # Main, deep features
            resnet50_base.get_layer("conv2_block3_out").output, # Skip connection, shallow features
        ],
    )
    feature_extractor.trainable = False

    # --- 2. Build the Full DeepLabV3+ Model ---
    # Define our 4-channel input
    model_input = keras.Input(shape=input_shape)

    # Adapt our 4-channel input to the 3 channels the feature extractor expects
    adapted_input = layers.Conv2D(3, (1, 1), padding='same')(model_input)

    # Get the two feature maps from our extractor
    main_features, skip_features = feature_extractor(adapted_input)

    # --- ASPP Branch ---
    # Process the deep features with Atrous Spatial Pyramid Pooling
    x = DilatedSpatialPyramidPooling(main_features)
    # Upsample to match the skip connection dimensions
    input_a = layers.UpSampling2D(
        size=(input_shape[0] // 4 // x.shape[1], input_shape[1] // 4 // x.shape[2]),
        interpolation="bilinear",
    )(x)

    # --- Skip Connection Branch ---
    # Process the shallow features
    input_b = convolution_block(skip_features, num_filters=48, kernel_size=1)

    # --- Decoder ---
    # Concatenate and refine the features
    x = layers.Concatenate(axis=-1)([input_a, input_b])
    x = convolution_block(x)
    x = convolution_block(x)
    # Upsample to the original image size
    x = layers.UpSampling2D(
        size=(input_shape[0] // x.shape[1], input_shape[1] // x.shape[2]),
        interpolation="bilinear",
    )(x)

    # --- Final Output Layer ---
    x = layers.Conv2D(num_classes, (1, 1), padding="same")(x)

    # --- Create and return the Keras Model ---
    model = keras.Model(inputs=model_input, outputs=x)
    return model


# --- 2. DATA PREPARATION (No changes from before) ---

def convert_mask_to_classes(mask_array):
    AGRI_COLOR = np.array([255, 255, 0])
    BARREN_COLOR = np.array([255, 255, 255])
    class_map = np.zeros((mask_array.shape[0], mask_array.shape[1]), dtype=np.uint8)
    class_map[np.all(mask_array == AGRI_COLOR, axis=-1)] = 1
    class_map[np.all(mask_array == BARREN_COLOR, axis=-1)] = 0
    return class_map

def load_deepglobe_data(dataset_dir, target_size=(256, 256), num_classes=3):
    logging.info(f"Loading DeepGlobe data from: {dataset_dir}")
    image_paths = glob.glob(os.path.join(dataset_dir, '*_sat.jpg'))
    X_data, Y_data = [], []
    for i, path in enumerate(image_paths):
        if i % 50 == 0: logging.info(f"  Processing image {i}/{len(image_paths)}...")
        with Image.open(path) as img:
            img = img.resize(target_size)
            img_array = np.array(img) / 255.0
        dummy_channel = np.zeros((target_size[0], target_size[1], 1))
        img_4_channel = np.concatenate([img_array, dummy_channel], axis=-1)
        X_data.append(img_4_channel)
        mask_path = path.replace('_sat.jpg', '_mask.png')
        with Image.open(mask_path) as mask_img:
            mask_img = mask_img.resize(target_size, Image.NEAREST)
            mask_array = np.array(mask_img)
        class_map = convert_mask_to_classes(mask_array)
        mask_one_hot = tf.keras.utils.to_categorical(class_map, num_classes=num_classes)
        Y_data.append(mask_one_hot)
    logging.info(f"Loaded {len(X_data)} images and masks.")
    return np.array(X_data, dtype=np.float32), np.array(Y_data, dtype=np.float32)

# --- 3. TRAINING ---
def main():
    log_file = 'training_log.txt'
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', handlers=[
        logging.FileHandler(log_file, mode='w', encoding='utf-8'), logging.StreamHandler()])
    
    try:
        # --- Parameters ---
        TARGET_SIZE = (256, 256)
        INPUT_SHAPE = (TARGET_SIZE[0], TARGET_SIZE[1], 4)
        NUM_CLASSES = 3
        DEEPGLOBE_DATA_DIR = "f:/SJBIT_AGRI_BACKUP/WaterStressApp/ai_model_training/unz_data/train"

        # --- Load Data ---
        X, Y = load_deepglobe_data(DEEPGLOBE_DATA_DIR, target_size=TARGET_SIZE, num_classes=NUM_CLASSES)
        X_train, X_val, Y_train, Y_val = train_test_split(X, Y, test_size=0.15, random_state=42)
        logging.info(f"Training samples: {len(X_train)}, Validation samples: {len(X_val)}")

        # --- Build the new DeepLabV3+ model ---
        logging.info("Building new DeepLabV3+ model...")
        model = build_deeplabv3plus(input_shape=INPUT_SHAPE, num_classes=NUM_CLASSES)
        
        # --- Compile ---
        # Note: The output of DeepLabV3+ is "logits" (raw scores), so we set from_logits=True.
        loss = keras.losses.CategoricalCrossentropy(from_logits=True)
        model.compile(optimizer=keras.optimizers.Adam(learning_rate=1e-4), 
                      loss=loss, 
                      metrics=['accuracy'])
        
        summary_list = []
        model.summary(print_fn=lambda x: summary_list.append(x))
        logging.info("Model Summary:\n" + "\n".join(summary_list))
        
        # --- Train ---
        logging.info("Starting training with new DeepLabV3+ model...")
        model.fit(X_train, Y_train, 
                  validation_data=(X_val, Y_val),
                  batch_size=4, 
                  epochs=25)
        
        # --- Save ---
        new_model_filename = 'deeplabv3plus_pretrained_deepglobe.h5'
        model.save(new_model_filename)
        logging.info(f"\n--- New model saved as {new_model_filename}! ---")

    except Exception as e:
        logging.error("An error occurred during training.")
        logging.error(traceback.format_exc())

if __name__ == "__main__":
    main()
