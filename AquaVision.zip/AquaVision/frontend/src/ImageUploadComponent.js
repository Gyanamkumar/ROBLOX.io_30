import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ImageUploadComponent.css'; // We'll add styles for this, too

// This is the URL of your local Python backend
const API_URL = 'http://localhost:5001';

const ImageUploadComponent = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [previewImage, setPreviewImage] = useState(null);
    const [recommendations, setRecommendations] = useState([]);
    const [resultMapUrl, setResultMapUrl] = useState('');
    const [aiSummary, setAiSummary] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [backendStatus, setBackendStatus] = useState('checking');

    // Check if the backend is running on component load
    useEffect(() => {
        axios.get(`${API_URL}/api/test`)
            .then(response => {
                if (response.data.model_loaded) {
                    setBackendStatus('ready');
                } else {
                    setBackendStatus('no_model');
                    setError("Backend is running, but the AI model failed to load. Check backend console.");
                }
            })
            .catch(err => {
                setBackendStatus('offline');
                setError("Backend server is offline. Please start the 'app.py' server.");
            });
    }, []);

    const onFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            setSelectedFile(file);
            setPreviewImage(URL.createObjectURL(file));
            // Clear old results
            setResultMapUrl('');
            setRecommendations([]);
            setError('');
        }
    };

    const onFileUpload = async () => {
        if (!selectedFile) {
            setError("Please select an image file first.");
            return;
        }
        
        setIsLoading(true);
        setError('');
        setResultMapUrl('');
        setRecommendations([]);

        const formData = new FormData();
        formData.append("image", selectedFile);

        try {
            // This sends the image to the LOCAL Flask server
            // NOTE: do NOT set the Content-Type header manually for multipart/form-data —
            // axios will set the correct boundary for you. Manually setting it can
            // trigger preflight OPTIONS or malformed requests leading to 405/415 errors.
            console.log('Uploading to', `${API_URL}/api/analyze-kmeans`, selectedFile);
            const response = await axios.post(`${API_URL}/api/analyze-kmeans`, formData);
            console.log('Analysis response', response.status, response.data);
            setRecommendations(response.data.recommendations || []);
            setResultMapUrl(response.data.map_url);
            setAiSummary(response.data.summary || '');

        } catch (error) {
            // Provide more helpful error messages to the user and log full response
            console.error("Analysis Error:", error);
            if (error.response) {
                const resp = error.response;
                const data = resp.data;
                let msg = '';
                if (data && typeof data === 'object') {
                    // Prefer explicit `error` field when available, otherwise stringify object
                    msg = data.error || JSON.stringify(data);
                } else {
                    msg = String(data || resp.statusText || resp);
                }
                setError(`Error ${resp.status}: ${msg}`);
            } else if (error.request) {
                // Request was made but no response
                setError('No response from server. Is the backend running?');
            } else {
                // Something else
                setError(error.message || 'Analysis failed.');
            }
        } finally {
            setIsLoading(false);
        }
    };

    // Helper to render bold text in recommendations
    const formatRecommendation = (rec) => {
        return rec.split('**').map((part, i) =>
            i % 2 === 1 ? <strong key={i}>{part}</strong> : part
        );
    };

    return (
        <div className="upload-container">
            {/* --- STATUS --- */}
            <div className="status-box">
                Backend Status:&nbsp;
                {backendStatus === 'ready' && <span className="status-ready">Ready</span>}
                {backendStatus === 'checking' && <span className="status-checking">Checking...</span>}
                {backendStatus === 'offline' && <span className="status-offline">Offline</span>}
                {backendStatus === 'no_model' && <span className="status-offline">Model Error</span>}
            </div>

            <div className="upload-grid">
                <div className="u-left">
                    <h3>1. Upload Your Field Image</h3>
                    <p className="muted">PNG or JPEG — the AI will analyze for crop stress.</p>

                    <div
                        className={`dropzone ${selectedFile ? 'has-file' : ''}`}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                            e.preventDefault();
                            const file = e.dataTransfer.files[0];
                            if (file) onFileChange({ target: { files: [file] } });
                        }}
                    >
                        {!previewImage ? (
                            <div className="drop-instructions">Drag & drop an image here<br/>or click to select</div>
                        ) : (
                            <img className="preview-image" src={previewImage} alt="Preview" />
                        )}
                        <input className="file-input" type="file" onChange={onFileChange} accept="image/png, image/jpeg" />
                    </div>

                    <div className="controls">
                        <button 
                            className="primary-btn"
                            onClick={onFileUpload} 
                            disabled={!selectedFile || isLoading || backendStatus !== 'ready'}>
                            {isLoading ? "Analyzing..." : "Run AI Analysis"}
                        </button>

                        <button 
                            className="secondary-btn"
                            onClick={() => { setSelectedFile(null); setPreviewImage(null); setRecommendations([]); setResultMapUrl(''); setError(''); }}>
                            Clear
                        </button>
                    </div>

                    {error && <div className="error-message">{error}</div>}
                </div>

                <div className="u-right">
                    {/* Loader / progress */}
                    {isLoading && (
                        <div className="progress-box">
                            <div className="spinner"></div>
                            <div className="progress-text">Analyzing — this may take a minute</div>
                        </div>
                    )}

                    {/* --- RESULTS --- */}
                    {(!isLoading && (resultMapUrl || recommendations.length > 0)) && (
                        <div className="results-card">
                            <h4>Analysis Results</h4>
                            <div className="results-grid">
                                <div className="result-image-box">
                                    <h5>Your Image</h5>
                                    {previewImage ? <img src={previewImage} alt="Uploaded field" /> : <div className="image-placeholder">No image</div>}
                                </div>
                                <div className="result-image-box">
                                    <h5>AI Stress Map</h5>
                                    {resultMapUrl ? <img src={resultMapUrl} alt="Stress analysis map" /> : <div className="image-placeholder">No map</div>}
                                </div>
                            </div>

                            {aiSummary && (
                                <div className="ai-summary">
                                    <h5>AI Summary</h5>
                                    <p>{aiSummary}</p>
                                </div>
                            )}

                            <div className="recommendations">
                                <h5>Actionable Advice</h5>
                                {recommendations.length > 0 ? (
                                    <ul>
                                        {recommendations.map((rec, idx) => (
                                            <li key={idx}>{formatRecommendation(rec)}</li>
                                        ))}
                                    </ul>
                                ) : <p className="muted">No specific recommendations.</p>}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ImageUploadComponent;