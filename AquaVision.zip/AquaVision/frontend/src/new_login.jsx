import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { auth } from './services/api';
import "./new_login.css";

// Note: Google sign-in requires backend/client setup (OAuth client ID + redirect).
// We provide a simple development fallback: if REACT_APP_GOOGLE_OAUTH_URL is set
// the button will open that URL. Otherwise a small mock modal lets you simulate
// a Google sign-in locally (development only).

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [gName, setGName] = useState('');
  const [gEmail, setGEmail] = useState('');
  const [gsiLoaded, setGsiLoaded] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Basic validation
    if (!email || !password) {
      setError("Please enter both email and password.");
      setIsLoading(false);
      return;
    }

    try {
      const response = await auth.login(email, password);
      // Store the token and user data
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      // Navigate to home page on successful login
      navigate("/");
    } catch (err) {
      console.error('Login error:', err);
      setError(err.response?.data?.error || "Login failed. Please check your credentials.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleClick = () => {
    const oauthUrl = process.env.REACT_APP_GOOGLE_OAUTH_URL || window.REACT_APP_GOOGLE_OAUTH_URL;
    const clientId = process.env.REACT_APP_GOOGLE_CLIENT_ID || window.REACT_APP_GOOGLE_CLIENT_ID;

    if (oauthUrl) {
      // Redirect the current window to the OAuth entrypoint (backend should handle callback)
      window.location.href = oauthUrl;
      return;
    }

    // If client-side GSI is configured, prompt the One Tap / picker
    if (clientId && window.google && window.google.accounts && window.google.accounts.id) {
      // Show the One Tap prompt (or the rendered button will handle signin)
      try {
        window.google.accounts.id.prompt();
        return;
      } catch (e) {
        console.warn('GSI prompt error', e);
      }
    }

    // Fallback: show mock modal to simulate Google sign-in
    setShowGoogleModal(true);
  };

  // Helper: decode JWT payload (client-side fallback only; server verification is recommended)
  const parseJwt = (token) => {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
      return JSON.parse(jsonPayload);
    } catch (e) {
      return null;
    }
  };

  // Called by GSI when the user signs in
  const handleCredentialResponse = async (response) => {
    // response.credential is the ID token (JWT)
    if (!response?.credential) return;
    setIsLoading(true);
    try {
      // Try to send to backend for verification / session creation
      if (auth && auth.googleSignIn) {
        try {
          const data = await auth.googleSignIn(response.credential);
          // expected backend response: { token, user }
          if (data?.token) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user || {}));
            navigate('/');
            window.location.reload();
            return;
          }
        } catch (err) {
          // Backend might not be implemented; we'll fallback to client decode
          console.warn('googleSignIn backend call failed', err?.response?.data || err);
        }
      }

      // Fallback: decode ID token client-side and store minimal user info (development only)
      const payload = parseJwt(response.credential);
      if (payload) {
        const user = { name: payload.name, email: payload.email, profileImage: payload.picture };
        localStorage.setItem('token', response.credential);
        localStorage.setItem('user', JSON.stringify(user));
        navigate('/');
        window.location.reload();
        return;
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Load GSI script and initialize if client id present
  useEffect(() => {
    const clientId = process.env.REACT_APP_GOOGLE_CLIENT_ID || window.REACT_APP_GOOGLE_CLIENT_ID;
    if (!clientId) return;

    // If script already loaded, just initialize
    const initialize = () => {
      try {
        if (window.google && window.google.accounts && window.google.accounts.id) {
          window.google.accounts.id.initialize({
            client_id: clientId,
            callback: handleCredentialResponse
          });

          // Render the official Google button into the placeholder
          const mount = document.getElementById('g_id_signin');
          if (mount) {
            try { window.google.accounts.id.renderButton(mount, { theme: 'outline', size: 'large' }); } catch(e) { console.warn('renderButton failed', e); }
          }

          setGsiLoaded(true);
        }
      } catch (e) {
        console.warn('GSI initialize error', e);
      }
    };

    if (window.google && window.google.accounts && window.google.accounts.id) {
      initialize();
      return;
    }

    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.defer = true;
    s.onload = initialize;
    s.onerror = () => console.warn('Failed to load Google Identity Services script');
    document.body.appendChild(s);

    return () => {
      // optional cleanup
    };
  }, []);

  const submitMockGoogle = () => {
    if (!gEmail) return;
    // Simulate backend response
    const fakeToken = 'fake-google-token-' + Date.now();
    const user = { name: gName || gEmail.split('@')[0], email: gEmail, profileImage: '' };
    localStorage.setItem('token', fakeToken);
    localStorage.setItem('user', JSON.stringify(user));
    setShowGoogleModal(false);
    navigate('/');
    window.location.reload();
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-visual">
          <h2>AquaVision</h2>
          <p>AI-Powered Water Use Efficiency Advisor.</p>
        </div>
        <div className="login-form">
          <h2>Welcome Back!</h2>
          <p>Please enter your details to login.</p>
          {error && <div className="error-message">{error}</div>}
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            <Link to="/forgot-password" className="forgot-password">
              Forgot password?
            </Link>
            <button type="submit" className="submit-btn" disabled={isLoading}>
              {isLoading ? "Logging in..." : "Login"}
            </button>
            <div className="divider">or</div>
            {(() => {
              const oauthUrl = process.env.REACT_APP_GOOGLE_OAUTH_URL || window.REACT_APP_GOOGLE_OAUTH_URL;
              const clientId = process.env.REACT_APP_GOOGLE_CLIENT_ID || window.REACT_APP_GOOGLE_CLIENT_ID;

              // If server-side OAuth entrypoint configured, show a redirect link
              if (oauthUrl) {
                return (
                  <a className="google-btn" href={oauthUrl} rel="noopener noreferrer">
                    <span style={{marginRight:10}}>G</span>
                    <span>Sign in with Google</span>
                  </a>
                );
              }

              // If client-side GSI available, render the official GSI button placeholder
              if (clientId) {
                return (
                  <div id="g_id_signin" style={{display:'inline-block'}}></div>
                );
              }

              // Otherwise fall back to the mock button/modal
              return (
                <button type="button" className="google-btn" disabled={isLoading} onClick={handleGoogleClick}>
                  <span style={{marginRight:10}}>G</span>
                  <span>Sign in with Google</span>
                </button>
              );
            })()}
          </form>
          <p className="signup-link">
            Don’t have an account?{" "}
            <Link to="/signup">
              Sign up
            </Link>
          </p>
        </div>
      </div>
      {showGoogleModal && (
        <div className="google-modal-overlay" onClick={() => setShowGoogleModal(false)}>
          <div className="google-modal" onClick={(e) => e.stopPropagation()}>
            <h3>Mock Google Sign-in</h3>
            <p>Development fallback: enter a name and email to simulate Google sign-in.</p>
            <div className="form-group">
              <label>Name</label>
              <input value={gName} onChange={(e) => setGName(e.target.value)} placeholder="Full name (optional)" />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input value={gEmail} onChange={(e) => setGEmail(e.target.value)} placeholder="you@gmail.com" />
            </div>
            <div style={{display:'flex', gap:8, justifyContent:'flex-end', marginTop:12}}>
              <button className="secondary-btn" onClick={() => setShowGoogleModal(false)}>Cancel</button>
              <button className="primary-btn" onClick={submitMockGoogle}>Continue</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}