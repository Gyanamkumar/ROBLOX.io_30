import React from 'react';
import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import Navbar from './new_Navbar';
import Home from './new_ho';
import About from './new_About';
import Contact from './new_Contact';
import Login from './new_login';
import Signup from './new_Signup';
import Profile from './new_Profile';
import ImageUploadComponent from './ImageUploadComponent';
import Sidebar from './new_sidebar';
import ForgotPassword from './new_ForgotPassword';
import './new_App.css'; // Import new global styles
import videoSrc from './2025.mp4';


// Layout component to wrap pages with Navbar and Sidebar
const AppLayout = () => (
  <div className="app-container">
    <video className="video-background" autoPlay loop muted>
      <source src={videoSrc} type="video/mp4" />
      Your browser does not support the video tag.
    </video>
    <Sidebar />
    <Navbar />
    <main className="main-content">
      <Outlet /> {/* Child routes will render here */}
    </main>
  </div>
);

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Home />} />
          <Route path="analyze" element={<ImageUploadComponent />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/profile" element={<Profile />} />
      
      
    
        </Route>
      </Routes>
    </Router>
  );
}
export default App;
