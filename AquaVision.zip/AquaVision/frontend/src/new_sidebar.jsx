import React, { useState } from 'react';
import './new_sidebar.css';
import { Link } from 'react-router-dom';

function Sidebar() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      {/* Button to open sidebar */}
      <button className="sidebar-btn" onClick={toggleSidebar}>
        ☰
      </button>

      {/* Sidebar itself */}
      <div className={`sidebar ${isOpen ? 'open' : ''}`}>
        <button className="close-btn" onClick={toggleSidebar}>×</button>
        <h2>Quick Menu</h2>
        <ul>
          <li><Link to="/" onClick={toggleSidebar}>🏠 Home</Link></li>
          <li><Link to="/about" onClick={toggleSidebar}>ℹ️ About</Link></li>
          <li><Link to="/contact" onClick={toggleSidebar}>📞 Contact</Link></li>
          <li><Link to="/profile" onClick={toggleSidebar}>👤 Profile</Link></li>
          <li><Link to="/login" onClick={toggleSidebar}>🔐 Login</Link></li>
        </ul>
      </div>

      {/* Overlay when sidebar is open */}
      {isOpen && <div className="overlay" onClick={toggleSidebar}></div>}
    </>
  );
}

export default Sidebar;
