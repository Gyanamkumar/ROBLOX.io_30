import React, { useState, useEffect } from 'react';
import { profile } from './services/api';
import './new_Profile.css';

function Profile() {
  const [user, setUser] = useState({
    name: '',
    email: '',
    bio: '',
    profileImage: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState({ ...user });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function loadProfile() {
      try {
        setIsLoading(true);
        setError('');
        
        // Get stored user email from login
        const storedUser = JSON.parse(localStorage.getItem('user'));
        if (!storedUser?.email) {
          throw new Error('No user logged in');
        }

        // Fetch user profile from backend
        const response = await profile.get(storedUser.email);
        const userData = response.user;
        
        // Add defaults for optional fields
        const userWithDefaults = {
          ...userData,
          bio: userData.bio || 'Software Developer',
          profileImage: userData.profileImage || 'https://via.placeholder.com/150'
        };
        
        setUser(userWithDefaults);
        setEditedUser(userWithDefaults);
      } catch (err) {
        console.error('Failed to load profile:', err);
        setError('Failed to load profile. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    }
    
    loadProfile();
  }, []);

  const handleEdit = () => {
    setEditedUser({ ...user });
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      setError('');
      setIsLoading(true);
      
      // Update profile via API
      const response = await profile.update(editedUser.email, {
        name: editedUser.name,
        bio: editedUser.bio
      });
      
      // Update local state with response data
      setUser(response.user);
      setIsEditing(false);
    } catch (err) {
      console.error('Failed to update profile:', err);
      setError('Failed to save changes. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditedUser({ ...user }); // Reset to original values
  };

  const handleChange = (e) => {
    setEditedUser({ ...editedUser, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setEditedUser({ ...editedUser, profileImage: URL.createObjectURL(e.target.files[0]) });
    }
  };

  return (
    <div className="profile-page">
      <div className="profile-card">
        <h1>Profile</h1>
        {error && <div className="error-message">{error}</div>}
        {isLoading && !error ? (
          <div className="loading">Loading profile...</div>
        ) : (
          <>
            <div className="profile-image">
              <img src={isEditing ? editedUser.profileImage : user.profileImage} alt="Profile" />
              {isEditing && <input type="file" accept="image/*" onChange={handleImageChange} disabled={isLoading} />}
            </div>
            <div className="profile-info">
              <div className="field">
                <label>Name:</label>
                {isEditing ? (
                  <input
                    name="name"
                    value={editedUser.name}
                    onChange={handleChange}
                    disabled={isLoading}
                  />
                ) : (
                  <p>{user.name}</p>
                )}
              </div>
              <div className="field">
                <label>Email:</label>
                <p>{user.email}</p>
              </div>
              <div className="field">
                <label>Bio:</label>
                {isEditing ? (
                  <textarea 
                    name="bio" 
                    value={editedUser.bio} 
                    onChange={handleChange}
                    disabled={isLoading}
                  />
                ) : (
                  <p>{user.bio}</p>
                )}
              </div>
            </div>
            <div className="buttons">
              {isEditing ? (
                <>
                  <button onClick={handleSave} disabled={isLoading}>
                    {isLoading ? "Saving..." : "Save"}
                  </button>
                  <button onClick={handleCancel} disabled={isLoading}>
                    Cancel
                  </button>
                </>
              ) : (
                <button onClick={handleEdit} disabled={isLoading}>
                  Edit Profile
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default Profile;