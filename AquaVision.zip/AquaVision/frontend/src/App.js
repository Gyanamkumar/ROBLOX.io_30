// Re-export the original app layout which lives in new_App.jsx
export { default } from './new_App';