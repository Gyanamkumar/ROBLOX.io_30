import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './new_login.css'; // Reusing login page styles

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) {
      setMessage(`A password reset link has been sent to ${email}`);
    }
  };

  return (
    <div className="login-page">
      <div className="login-container" style={{ height: 'auto' }}>
        <div className="login-form" style={{ padding: '40px' }}>
          <h2>Forgot Password</h2>
          <p>Enter your email to reset your password.</p>
          {message && <div className="success-message">{message}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="submit-btn">
              Send Reset Link
            </button>
          </form>
          <p className="signup-link">
            Remember your password?{' '}
            <Link to="/login">
              Login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
