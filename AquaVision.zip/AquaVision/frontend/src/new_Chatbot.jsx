// Chatbot component removed per request. Keep a harmless stub to avoid import errors.
import React from 'react';

export default function ChatBot() {
  return null; // no-op
}
