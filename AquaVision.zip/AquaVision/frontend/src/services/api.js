import axios from 'axios';

// Create base API configuration
export const API_URL = 'http://localhost:5001';

// Create an axios instance with default config
const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Add auth token to requests if it exists
api.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Auth API calls
export const auth = {
    login: async (email, password) => {
        const response = await api.post('/api/auth/login', { email, password });
        return response.data;
    },
    register: async (name, email, password) => {
        const response = await api.post('/api/auth/register', { name, email, password });
        return response.data;
    }
    ,
    // Exchange Google credential (ID token) with backend to create/verify session
    googleSignIn: async (credential) => {
        const response = await api.post('/api/auth/google', { credential });
        return response.data;
    }
};

// Profile API calls
export const profile = {
    get: async (email) => {
        const response = await api.get(`/api/profile?email=${email}`);
        return response.data;
    },
    update: async (email, updates) => {
        const response = await api.put('/api/profile', { email, ...updates });
        return response.data;
    }
};

// Contact form API calls
export const contact = {
    send: async (name, email, message) => {
        const response = await api.post('/api/contact', { name, email, message });
        return response.data;
    }
};

// Chatbot API calls
export const chatbot = {
    sendMessage: async (message) => {
        const response = await api.post('/api/chatbot', { message });
        return response.data;
    }
};

// AI Analysis API calls
export const analysis = {
    testBackend: async () => {
        const response = await api.get('/api/test');
        return response.data;
    },
    analyzeImage: async (imageFile) => {
        const formData = new FormData();
        formData.append('image', imageFile);
        const response = await api.post('/api/analyze-local-image', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    }
};

export default api;