export const signUp = async ({ email, password }) => {
  // Simulate signup by storing in localStorage
  const user = { email, password };
  localStorage.setItem('user', JSON.stringify(user));
  return Promise.resolve();
};
