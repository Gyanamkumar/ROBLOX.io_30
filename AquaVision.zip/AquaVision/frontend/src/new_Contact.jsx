import React, { useState } from "react";
import "./new_Contact.css";
import { FaEnvelope, FaPhone, FaMapMarkerAlt } from "react-icons/fa";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Message sent:", formData);
    setSubmitted(true);
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="contact-page">
      <div className="contact-container">
        <h1>Contact Us</h1>
        <p className="intro">
          Have any questions or feedback? We’d love to hear from you!  
          Fill out the form below or reach us using the details provided.
        </p>

        <div className="contact-content">
          <div className="contact-info">
            <h3>Get in Touch</h3>
            <p><FaEnvelope className="icon" /> support@phishresilience.com</p>
            <p><FaPhone className="icon" /> +91 98765 43210</p>
            <p><FaMapMarkerAlt className="icon" /> Bengaluru, India</p>
          </div>

          <div className="contact-form">
            {!submitted ? (
              <form onSubmit={handleSubmit}>
                <input
                  type="text"
                  name="name"
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Your Email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
                <textarea
                  name="message"
                  placeholder="Your Message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  required
                ></textarea>
                <button type="submit">Send Message</button>
              </form>
            ) : (
              <div className="thank-you">
                <h3>Thank you!</h3>
                <p>Your message has been sent successfully.</p>
                <button onClick={() => setSubmitted(false)}>Send Another</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
