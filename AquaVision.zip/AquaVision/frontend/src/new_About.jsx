import React from "react";

export default function About() {
  return (
   
    <div className="a11" >
      <h1 className="text-3xl font-bold text-blue-700 mb-4 text-center">
        About the Project
      </h1>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Project Overview</h2>
        <p className="text-gray-700 leading-relaxed">
          The <strong>AI-Powered Water Use Efficiency Advisor</strong> is an
          intelligent platform designed to optimize agricultural water usage
          through the analysis of satellite imagery snapshots. Using artificial
          intelligence and remote sensing techniques, the system detects
          irrigation inefficiencies and provides actionable insights to
          maximize water productivity and crop yield.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Problem Statement</h2>
        <p className="text-gray-700 leading-relaxed">
          Agriculture accounts for nearly 70% of global freshwater withdrawals.
          However, inefficient irrigation practices, water losses, and
          unmonitored field conditions lead to significant wastage. Farmers lack
          accessible tools to monitor water use in real time and make
          data-driven irrigation decisions. This project aims to bridge that gap
          using AI and satellite data.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Objectives</h2>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed">
          <li>Analyze satellite images to detect irrigation patterns and soil moisture.</li>
          <li>Assess vegetation health using indices like NDVI and NDWI.</li>
          <li>Provide personalized water management recommendations for each field.</li>
          <li>Enhance sustainability by reducing water wastage and improving crop productivity.</li>
        </ul>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Proposed Solution</h2>
        <p className="text-gray-700 leading-relaxed">
          The proposed system leverages AI algorithms trained on satellite
          imagery to analyze vegetation indices and soil conditions. The
          platform processes images to estimate water stress levels, visualize
          inefficiencies, and generate actionable insights for farmers or water
          resource managers. Users can upload satellite snapshots through an
          interactive web interface built with React, where analysis results are
          visualized using color-coded heatmaps.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">System Workflow</h2>
        <p className="text-gray-700 leading-relaxed">
          The workflow consists of:
        </p>
        <ul className="list-decimal list-inside text-gray-700 leading-relaxed">
          <li>Users upload satellite snapshots of their agricultural land.</li>
          <li>The system pre-processes images to extract relevant features.</li>
          <li>AI models compute vegetation and water indices (NDVI, NDWI).</li>
          <li>Results are visualized as heatmaps indicating areas of water stress.</li>
          <li>Advisory suggestions are generated for optimal irrigation planning.</li>
        </ul>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Technologies Used</h2>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed">
          <li><strong>Frontend:</strong> React.js, Tailwind CSS, Vite</li>
          <li><strong>Backend (optional):</strong> Node.js, Express.js</li>
          <li><strong>AI / Data Analysis:</strong> Python, OpenCV, TensorFlow / PyTorch</li>
          <li><strong>Satellite Data:</strong> Sentinel-2, Landsat 8, PlanetScope</li>
          <li><strong>Visualization:</strong> NDVI/NDWI heatmaps, Chart.js</li>
        </ul>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Expected Outcomes</h2>
        <p className="text-gray-700 leading-relaxed">
          The system aims to help farmers and agricultural agencies:
        </p>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed">
          <li>Reduce water wastage and energy costs.</li>
          <li>Improve crop yield and sustainability.</li>
          <li>Enable AI-driven precision irrigation decisions.</li>
          <li>Promote long-term agricultural water conservation.</li>
        </ul>
      </section>

      <section className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Future Enhancements</h2>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed">
          <li>Integrate real-time IoT sensor data for field-level accuracy.</li>
          <li>Implement rainfall and weather forecasting models.</li>
          <li>Provide mobile app access for field workers.</li>
          <li>Enable multi-season and crop-based water efficiency reports.</li>
        </ul>
      </section>

      <section className="mb-4">
        <h2 className="text-2xl font-semibold mb-2">Conclusion</h2>
        <p className="text-gray-700 leading-relaxed">
          The AI-Powered Water Use Efficiency Advisor demonstrates how modern
          technologies like AI and remote sensing can revolutionize sustainable
          agriculture. By providing accessible tools to monitor and optimize
          water use, this project contributes toward smarter farming and
          environmental conservation.
        </p>
      </section>
    </div>
    
  );
}