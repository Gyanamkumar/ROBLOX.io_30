import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import './new_Navbar.css'; // We'll style it next
import { FaWater } from "react-icons/fa";

function Navbar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  const location = useLocation();
  useEffect(() => {
    const stored = localStorage.getItem('user') || localStorage.getItem('token');
    setIsLoggedIn(!!stored);
  }, [location.pathname]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    setIsLoggedIn(false);
    navigate('/');
    // reload to update any UI relying on auth
    window.location.reload();
  };

  return (
    <nav className="navbar">
      <h2 className="logo"><FaWater className="icon" />AquaVision</h2>

      <ul className="nav-links">
        <li className="a21"><Link to="/">Home</Link></li>
        <li><Link to="/about">About</Link></li>
        <li><Link to="/contact">Contact</Link></li>
        <li><Link to="/analyze">Analyze</Link></li>

        {/* Only show login and signup links when not logged in */}
        {!isLoggedIn && (
          <>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/signup">Sign Up</Link></li>
          </>
        )}

        {/* Show profile only when logged in */}
        {isLoggedIn && (
          <li><Link to="/profile">Profile</Link></li>
        )}

        {/* If logged in, show logout button */}
        {isLoggedIn && (
          <li>
            <button className="nav-logout" onClick={handleLogout}>Logout</button>
          </li>
        )}
      </ul>
    </nav>
  );
}


export default Navbar;




