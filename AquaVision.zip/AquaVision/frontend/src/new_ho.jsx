import React, { useEffect, useState } from "react"
import "./new_ho.css"
import { useNavigate } from "react-router-dom"

export default function Home() {
  const navigate = useNavigate()
  const [showPrompt, setShowPrompt] = useState(false)

  useEffect(() => {
    const logged = !!(localStorage.getItem('user') || localStorage.getItem('token'))
    const promptShown = localStorage.getItem('loginPromptShown') === '1'
    // If not logged in and prompt hasn't been shown, show it shortly after landing
    if (!logged && !promptShown) {
      const t = setTimeout(() => setShowPrompt(true), 1200)
      return () => clearTimeout(t)
    }
  }, [])

  const closePrompt = (dontShowAgain = false) => {
    if (dontShowAgain) localStorage.setItem('loginPromptShown', '1')
    setShowPrompt(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white text-gray-800">
      {/* 🌱 Hero Section */}
      <div className="a23">
      <section className="text-center py-16 px-6">
        <h1 className="text-4xl sm:text-5xl font-extrabold text-blue-700 mb-4">
          AI Water Use Efficiency Advisor
        </h1>

        <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-6">
          Empower your agriculture with AI insights from satellite snapshots.
          Identify irrigation inefficiencies, optimize water use, and enhance sustainability.
        </p>

        {/* Buttons: Analyze (left) and Get Started (right). Analyze sits 60px left of Get Started */}
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '0' }}>
          <button
            onClick={() => navigate('/analyze')}
            className="analyze"
            style={{ marginRight: '60px' } }
            
          >
            Analyze
          </button>

          <button
            onClick={() => navigate("/signup")}
            className="get"
          >
            Get Started
          </button>
        </div>
      </section>
</div>
      {/* 🌍 Features Section */}
      <section className="py-14 bg-white">
        <h2 className="a23">
          How It Works
        </h2>
        <div className="s33">
          <div className="a25">
            <h3 className="text-xl font-semibold mb-2">🛰 Satellite Imagery</h3>
            <p className="text-gray-600">
              Upload or connect your field’s satellite images for real-time analysis of water distribution.
            </p>
          </div>
          
          <div className="a25 s2">
            <h3 className="text-xl font-semibold mb-2">🤖 AI Analysis</h3>
            <p className="text-gray-600">
              Our AI models calculate NDVI, NDWI, and soil moisture indices to detect irrigation inefficiencies.
            </p>
          </div>
          <div className="a25">
            <h3 className="text-xl font-semibold mb-2">💧 Smart Suggestions</h3>
            <p className="text-gray-600">
              Receive data-driven recommendations to optimize water use and improve crop yield.
            </p>
          </div>
        </div>
      </section>
      <br></br>

      {/* 🌾 Call to Action Section */}
      <section className="a23">
        <h2 className="text-3xl font-bold mb-3">Ready to Improve Water Efficiency?</h2>
        <p className="mb-6">
          Join today to get personalized AI insights from your satellite data.
        </p>
        <button
          onClick={() => navigate("/signup")}
          className="signup"
        >
          Sign Up Now
        </button>
      </section>
      {/* Login Prompt Modal */}
      {showPrompt && (
        <div className="login-modal-overlay" onClick={() => closePrompt(false)}>
          <div className="login-modal" onClick={(e) => e.stopPropagation()}>
            <h3>Welcome to AquaVision</h3>
            <p>To save your analyses and access personalized features, please login or sign up.</p>
            <div className="modal-actions">
              <button className="modal-login" onClick={() => navigate('/login')}>Login</button>
              <button className="modal-signup" onClick={() => navigate('/signup')}>Sign Up</button>
              <button className="modal-later" onClick={() => closePrompt(true)}>Maybe later</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

  {/* Login Prompt Modal */}
  // NOTE: JSX below is conditional and will be rendered by the component return above
