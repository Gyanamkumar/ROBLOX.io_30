# app.py
# Flask backend for WaterStressApp - extended with auth, contact, profile, and chatbot endpoints.

import os
import time
import json
import uuid
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

# AI deps (kept, used by the image analysis endpoint)
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors

# --- 0. SETUP & CONFIGURATION ---
app = Flask(__name__)
CORS(app) # Allow React app (running on different port) to talk to this

# Define folders
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
DATA_FOLDER = '.'
USERS_FILE = os.path.join(DATA_FOLDER, 'users.json')
CONTACTS_FILE = os.path.join(DATA_FOLDER, 'contacts.json')

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

# Ensure user/contact files exist
if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, 'w') as f:
        json.dump({}, f)
if not os.path.exists(CONTACTS_FILE):
    with open(CONTACTS_FILE, 'w') as f:
        json.dump([], f)

# --- AI model / visualization settings ---
CLASS_NAMES = ['Bare Soil', 'Healthy Crop', 'Stressed Crop']
STRESSED_CLASS_ID = 2
CLASS_COLORS = ['#8B4513', '#228B22', '#FF4500']
CMAP = matplotlib.colors.ListedColormap(CLASS_COLORS)

# --- 1. LOAD THE AI MODEL ---
MODEL_PATH = 'stress_segmentation_model.h5'
model = None
try:
    model = tf.keras.models.load_model(MODEL_PATH)
    print(f"--- Model '{MODEL_PATH}' loaded successfully! ---")
except Exception as e:
    print(f"--- WARNING: Could not load model '{MODEL_PATH}' ---")
    print(e)
    # App will still run for non-AI endpoints

# --- Utility functions for simple JSON-backed user store ---

def load_users():
    with open(USERS_FILE, 'r') as f:
        return json.load(f)

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)

def add_contact(contact):
    with open(CONTACTS_FILE, 'r') as f:
        contacts = json.load(f)
    contacts.append(contact)
    with open(CONTACTS_FILE, 'w') as f:
        json.dump(contacts, f, indent=2)

# --- Image preprocessing & postprocessing (kept from original) ---

def preprocess_image_for_model(image_path):
    img = tf.keras.utils.load_img(image_path, target_size=(256, 256))
    img_array = tf.keras.utils.img_to_array(img)
    if img_array.shape[2] == 3:
        fake_nir_channel = img_array[:, :, 2:3]
        img_array = np.concatenate([img_array, fake_nir_channel], axis=-1)
    img_array = img_array / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array


def process_and_save_mask(mask_prediction):
    recommendations = []
    stress_map = np.argmax(mask_prediction[0], axis=-1)
    h, w = stress_map.shape
    h_mid, w_mid = h // 2, w // 2
    quadrants = {
        "North-West": stress_map[0:h_mid, 0:w_mid],
        "North-East": stress_map[0:h_mid, w_mid:],
        "South-West": stress_map[h_mid:, 0:w_mid],
        "South-East": stress_map[h_mid:, w_mid:]
    }
    for name, quad in quadrants.items():
        if quad.size == 0:
            continue
        stress_pixels = np.sum(quad == STRESSED_CLASS_ID)
        total_pixels = quad.size
        stress_percent = (stress_pixels / total_pixels) * 100
        if stress_percent > 15.0:
            recommendations.append(f"AI detected high stress in **{name} quadrant** ({stress_percent:.0f}%).")
    if not recommendations:
        recommendations.append("AI analysis complete. No significant stress zones detected.")

    output_filename = f"mask_{int(time.time())}.png"
    output_path = os.path.join(RESULT_FOLDER, output_filename)
    plt.imsave(output_path, stress_map, cmap=CMAP, vmin=0, vmax=len(CLASS_NAMES)-1)
    map_url = request.host_url + f"results/{output_filename}"
    return recommendations, map_url

# --- API ENDPOINTS ---

@app.route('/api/test', methods=['GET'])
def test_api():
    return jsonify({"message": "Backend server is running!", "model_loaded": model is not None})

# --- Image analysis (kept) ---
@app.route('/api/analyze-local-image', methods=['POST'])
def analyze_image():
    if model is None:
        return jsonify({"error": "AI model is not loaded. Check backend console."}), 500
    if 'image' not in request.files:
        return jsonify({"error": "No 'image' file part found in the request."}), 400
    file = request.files['image']
    if file.filename == '':
        return jsonify({"error": "No selected file."}), 400
    try:
        filename = file.filename
        upload_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(upload_path)
        input_data = preprocess_image_for_model(upload_path)
        predicted_mask = model.predict(input_data)
        recommendations, map_url = process_and_save_mask(predicted_mask)
        os.remove(upload_path)
        return jsonify({"recommendations": recommendations, "map_url": map_url})
    except Exception as e:
        print(f"Error during analysis: {e}")
        if 'upload_path' in locals() and os.path.exists(upload_path):
            os.remove(upload_path)
        return jsonify({"error": f"An internal error occurred: {e}"}), 500

# Serve generated result images
@app.route('/results/<filename>')
def serve_result_image(filename):
    return send_from_directory(RESULT_FOLDER, filename)

# --- Contact endpoint (frontend's Contact page can POST here) ---
@app.route('/api/contact', methods=['POST'])
def contact():
    data = request.get_json() or {}
    name = data.get('name')
    email = data.get('email')
    message = data.get('message')
    if not (name and email and message):
        return jsonify({"error": "Missing form fields (name, email, message required)."}), 400
    contact_entry = {"id": str(uuid.uuid4()), "name": name, "email": email, "message": message, "created_at": time.ctime()}
    add_contact(contact_entry)
    return jsonify({"message": "Contact received", "entry": contact_entry}), 201

# --- Simple auth endpoints (JSON file-backed) ---
@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    name = data.get('name')
    email = data.get('email')
    password = data.get('password')
    if not (email and password):
        return jsonify({"error": "Email and password required."}), 400
    users = load_users()
    if email in users:
        return jsonify({"error": "User already exists."}), 409
    users[email] = {
        "id": str(uuid.uuid4()),
        "name": name or "",
        "email": email,
        "password_hash": generate_password_hash(password)
    }
    save_users(users)
    return jsonify({"message": "User registered."}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email')
    password = data.get('password')
    users = load_users()
    user = users.get(email)
    if not user or not check_password_hash(user.get('password_hash', ''), password):
        return jsonify({"error": "Invalid credentials."}), 401
    # For demo return a simple session token (not a secure JWT)
    token = str(uuid.uuid4())
    return jsonify({"message": "Login successful.", "user": {"id": user['id'], "name": user.get('name'), "email": user.get('email')}, "token": token})

# --- Profile endpoints ---
@app.route('/api/profile', methods=['GET'])
def get_profile():
    email = request.args.get('email')
    if not email:
        return jsonify({"error": "email query parameter required"}), 400
    users = load_users()
    user = users.get(email)
    if not user:
        return jsonify({"error": "User not found."}), 404
    # Do not return password hash
    user_safe = {k: v for k, v in user.items() if k != 'password_hash'}
    return jsonify({"user": user_safe})

@app.route('/api/profile', methods=['PUT'])
def update_profile():
    data = request.get_json() or {}
    email = data.get('email')
    if not email:
        return jsonify({"error": "email is required"}), 400
    users = load_users()
    user = users.get(email)
    if not user:
        return jsonify({"error": "User not found."}), 404
    # Update allowed fields
    for field in ['name']:
        if field in data:
            user[field] = data[field]
    users[email] = user
    save_users(users)
    user_safe = {k: v for k, v in user.items() if k != 'password_hash'}
    return jsonify({"message": "Profile updated.", "user": user_safe})

# --- Chatbot endpoint (simple rule-based replies) ---
@app.route('/api/chatbot', methods=['POST'])
def chatbot():
    data = request.get_json() or {}
    message = (data.get('message') or '').lower()
    reply = "Sorry, I didn't understand that. Try 'home', 'about', or 'contact'."
    if 'home' in message:
        reply = 'Navigating to Home 🏠'
    elif 'about' in message:
        reply = 'Here is the About page 📘'
    elif 'contact' in message:
        reply = 'Taking you to Contact 📞'
    elif 'login' in message or 'signup' in message:
        reply = 'Opening Login/Signup page 🔐'
    elif 'features' in message:
        reply = 'Features: satellite analysis, AI insights, smart irrigation suggestions.'
    return jsonify({"reply": reply})

# --- 404 / static frontend serving (optional) ---
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    # This will let you serve a built frontend from a 'frontend/build' folder if you create one.
    build_dir = os.path.join('..', 'frontend', 'build')
    if path != '' and os.path.exists(os.path.join(build_dir, path)):
        return send_from_directory(build_dir, path)
    return jsonify({"message": "Backend running. API available under /api/"})

# --- RUN ---
if __name__ == '__main__':
    print('--- Starting Flask Server ---')
    print('Access the API at http://localhost:5001')
    app.run(debug=True, port=5001)
